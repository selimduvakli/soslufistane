#include "system.h"

/*
	Main application
 */
int main(void)
{	
    // initialize the device
    SYSTEM_Initialize();

	// initialize comms early
	commsInit();
	
	// allow power supplies to come up
	__delay_ms(1000);
	
	ess9038Init();
	conversInit();
	controlInit();
	
    while (1)
    {
		commsMgr();
		controlMgr();
		ess9038Mgr();
		conversMgr();
    }
	
	// should never get here!
    return -1; 
}