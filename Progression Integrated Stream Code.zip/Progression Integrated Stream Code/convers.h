#ifndef _CONVERS_H
#define _CONVERS_H

typedef enum
{
	CONVERS_INPUT_PHONO				= 0x01,
	CONVERS_INPUT_AUX				= 0x02,
	CONVERS_INPUT_THEATER			= 0x03,
	CONVERS_INPUT_RADIO				= 0x04,
	CONVERS_INPUT_SERVER			= 0x05,
	CONVERS_INPUT_DAC				= 0x06,
	CONVERS_INPUT_COAXIAL			= 0x07,
	CONVERS_INPUT_OPTICAL			= 0x08,
	CONVERS_INPUT_USB				= 0x09,
	CONVERS_INPUT_NETWORK			= 0x0A,
		
	CONVERS_NUM_INPUTS	// leave last
} CONVERS_INPUT;

void conversInit(void);
void conversMgr(void);
bool conversPowerGet(void);
void conversPowerSet(bool enabled);
CONVERS_INPUT conversInputGet(void);
void conversInputSet(CONVERS_INPUT input);
uint8_t conversVolumeGet(void);
void conversVolumeSet(uint8_t volume);
bool conversMuteGet(void);
void conversMuteSet(bool enabled);
int8_t conversBalanceGet(void);
void conversBalanceSet(int8_t balance);
bool conversPhaseGet(void);
void conversPhaseSet(bool outOfPhase);
bool conversDarkModeGet(void);
void conversDarkModeSet(bool enabled);
void converseWifiConfigEnable(bool enable);

#endif