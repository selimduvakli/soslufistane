#include "system.h"

#define ESS9038_I2C_ADDRESS (0x90 >> 1)
#define ES9038_CHIP_ID		0x2A

#define ESS9038_REGISTER_ADDRESS_SYSTEM_REGISTERS			0
#define ESS9038_REGISTER_ADDRESS_INPUT_SELECTION			1
#define ESS9038_REGISTER_ADDRESS_SERIAL_AUTOMUTE_CONFIG		2
#define ESS9038_REGISTER_ADDRESS_DEEMPHASIS					6
#define ESS9038_REGISTER_ADDRESS_FILTER_BANDWIDTH			7
#define ESS9038_REGISTER_ADDRESS_GPIO_12_CONFIG				8
#define ESS9038_REGISTER_ADDRESS_GPIO_34_CONFIG				9
#define ESS9038_REGISTER_ADDRESS_SPDIF_MUX					11
#define ESS9038_REGISTER_ADDRESS_DPLL_BANDWIDTH				12
#define ESS9038_REGISTER_ADDRESS_DPLL_CONFIG				13
#define ESS9038_REGISTER_ADDRESS_GPIO_INPUT_SELECT			15
#define ESS9038_REGISTER_ADDRESS_VOLUME_1					16
#define ESS9038_REGISTER_ADDRESS_MASTER_TRIM_1				24
#define ESS9038_REGISTER_ADDRESS_CHIP_ID_STATUS				64

typedef struct
{
	uint8_t regAddress;
	uint8_t value;
} ESS9038_Default_Register_Setting_t;

ESS9038_Default_Register_Setting_t dacInit[] = 
{
	{
		ESS9038_REGISTER_ADDRESS_SYSTEM_REGISTERS,
		0xF0	// shutdown the oscillator, divide MCLK/2 to save heat
	},
	{
		ESS9038_REGISTER_ADDRESS_INPUT_SELECTION,
		0x01	// select spdif input
	},
	{
		ESS9038_REGISTER_ADDRESS_SERIAL_AUTOMUTE_CONFIG,
		0x3C	// defaults
	},
	{
		ESS9038_REGISTER_ADDRESS_DEEMPHASIS,
		0x5A	// auto-deemphasis enabled at 44.1
	},
	{
		ESS9038_REGISTER_ADDRESS_GPIO_12_CONFIG,
		0x1A	// gpio1 = mute input, gpio2 = lock status output
	},
	{
		ESS9038_REGISTER_ADDRESS_GPIO_34_CONFIG,
		0x70	// gpio3 = automute status output, gpio4 = output low (unused))
	},
	{
		ESS9038_REGISTER_ADDRESS_SPDIF_MUX,
		0x80	// spdif is input on data8
	},
	{
		ESS9038_REGISTER_ADDRESS_GPIO_INPUT_SELECT,
		0x0F	// enable stereo mode
	},
};

/*
	{
		ESS9038_REGISTER_ADDRESS_INPUT_SELECTION,
		0x0C	// defaults - auto-select input
	},

	{
		ESS9038_REGISTER_ADDRESS_VOLUME_1,
		0xFF	// enable stereo mode
	},
*/

static bool ess9038RegisterWrite(uint8_t registerAddress, uint8_t value);
static bool ess9038RegsisterRead(uint8_t registerAddress, uint8_t *value);

void ess9038Init(void)
{
	uint8_t result;
	uint8_t data;
	
	// allow clocks and supplies to settle
	__delay_ms(100);	
	
    // take the DAC out of reset
    nDAC_RESET_SetHigh();

	// allow DAC to boot
	__delay_ms(100);
	
	// verify communication with the DAC by reading the chip id
	result = ess9038RegsisterRead(ESS9038_REGISTER_ADDRESS_CHIP_ID_STATUS, &data);
	
	uint8_t chipID = data >> 2;
	
	if (	result == true
		 && chipID == ES9038_CHIP_ID )
	{
		uint8_t i;
		uint8_t numRegisters = sizeof(dacInit) / sizeof(ESS9038_Default_Register_Setting_t);
		ESS9038_Default_Register_Setting_t *entry = dacInit;
		for( i = 0; i < numRegisters; i++ )
		{
			result = ess9038RegisterWrite(entry->regAddress, entry->value);
			
			if  ( result == false )	
			{
				// handle error here!!!
				while(1);
			}
			
			entry++;
		}

		// enable the analog voltages
		RLY_ANALOG_SetHigh();
		
		// allow circuit to settle
		__delay_ms(100);
		
		// un-mute the output relays
		
		RLY_MUTE_SetHigh();
		
		// allow circuit to settle
		__delay_ms(100);
		
		// finally, un-mute the dac
		DAC_MUTE_SetLow();
	}
	else
	{
		// handle error here!!!
		//while(1);
	}
}

void ess9038Mgr(void)
{
	// nothing to do here right now	
}

void ess9038SetInput(ESS9038_INPUT input)
{
	switch( input )
	{
		case ESS9038_INPUT_SPDIF:
			// select spdif input
			ess9038RegisterWrite(ESS9038_REGISTER_ADDRESS_INPUT_SELECTION, 1);		
			break;
			
		case ESS9038_INPUT_I2S:
			// select serial data input	
			ess9038RegisterWrite(ESS9038_REGISTER_ADDRESS_INPUT_SELECTION, 0);		
			break;
			
		default:
			// @todo default to auto?
			break;
	}

}

static bool ess9038RegisterWrite(uint8_t registerAddress, uint8_t value)
{
	bool result = false;
	I2C1_MESSAGE_STATUS status;
	uint8_t data[2];
	
	// verify communication with the DAC by reading the chip id
	data[0] = registerAddress;
	data[1] = value;
	I2C1_MasterWrite( data, 2, ESS9038_I2C_ADDRESS, &status );
    while ( status == I2C1_MESSAGE_PENDING );
	if  ( status == I2C1_MESSAGE_COMPLETE )
	{
		result = true;
	}
	
	return result;
}

static bool ess9038RegsisterRead(uint8_t registerAddress, uint8_t *value)
{
	bool result = false;
	I2C1_MESSAGE_STATUS status;
	uint8_t data;
	
	data = registerAddress;
	I2C1_MasterWrite( &data, 1, ESS9038_I2C_ADDRESS, &status );
    while ( status == I2C1_MESSAGE_PENDING );
	if  ( status == I2C1_MESSAGE_COMPLETE )
	{
		data = 0;
		I2C1_MasterRead( &data, 1, ESS9038_I2C_ADDRESS, &status );
		while ( status == I2C1_MESSAGE_PENDING );
		if  ( status == I2C1_MESSAGE_COMPLETE )
		{
			*value = data;
			result = true;
		}
	}
	
	return result;
}

bool pollLock(void)
{
	bool locked = false;
	
	uint8_t data;
	
	ess9038RegsisterRead(ESS9038_REGISTER_ADDRESS_CHIP_ID_STATUS, &data);

	if ( (data & 0x01) == 1 )
	{
		locked = true;
	}
	
	return locked;
}