#include "system.h"

// this code implements a comms i2c slave + interrupt with the logic board

typedef enum
{
	I2C_SLAVE_COMMAND_GET_VERSION			= 0x01,
	I2C_SLAVE_COMMAND_GET_INTERRUPT_STATUS	= 0x02,
	I2C_SLAVE_COMMAND_GET_POWER				= 0x0A,
	I2C_SLAVE_COMMAND_SET_POWER				= 0x0B,
	I2C_SLAVE_COMMAND_GET_INPUT				= 0x10,
	I2C_SLAVE_COMMAND_SET_INPUT				= 0x11,
	I2C_SLAVE_COMMAND_GET_VOLUME			= 0x20,
	I2C_SLAVE_COMMAND_SET_VOLUME			= 0x21,
	I2C_SLAVE_COMMAND_GET_MUTE				= 0x22,
	I2C_SLAVE_COMMAND_SET_MUTE				= 0x23,
	I2C_SLAVE_COMMAND_GET_BALANCE			= 0x24,
	I2C_SLAVE_COMMAND_SET_BALANCE			= 0x25,
	I2C_SLAVE_COMMAND_GET_PHASE				= 0x2A,
	I2C_SLAVE_COMMAND_SET_PHASE				= 0x2B,
	I2C_SLAVE_COMMAND_GET_DARKMODE			= 0x30,	
	I2C_SLAVE_COMMAND_SET_DARKMODE			= 0x31,
	I2C_SLAVE_COMMAND_CONFIGURE_WIFI		= 0x40,
} I2C_SLAVE_COMMAND;

typedef enum
{
	COMMS_INPUT_PHONO			= 0x01,
	COMMS_INPUT_AUX				= 0x02,
	COMMS_INPUT_THEATER			= 0x03,
	COMMS_INPUT_RADIO			= 0x04,
	COMMS_INPUT_SERVER			= 0x05,
	COMMS_INPUT_DAC				= 0x06,
	COMMS_INPUT_COAXIAL			= 0x07,
	COMMS_INPUT_OPTICAL			= 0x08,
	COMMS_INPUT_USB				= 0x09,
	COMMS_INPUT_NETWORK			= 0x0A,
		
	COMMS_INPUT_INPUTS	// leave last
} COMMS_INPUT;

uint8_t statusReg;

volatile bool i2cSlaveCommandPending = false;

uint8_t i2cSlaveWriteBuffer[8];
uint8_t *i2cSlaveWriteBufferPtr;

uint8_t i2cSlaveReadBuffer[8];
uint8_t *i2cSlaveReadBufferPtr;

void commsInit(void)
{
	i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
	I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);

	i2cSlaveWriteBufferPtr = i2cSlaveWriteBuffer;
	I2C2_WritePointerSet(i2cSlaveWriteBufferPtr);
}

void commsMgr(void)
{
	if ( i2cSlaveCommandPending )
	{
		uint8_t i2cSlaveBytesReceieved = i2cSlaveWriteBufferPtr - i2cSlaveWriteBuffer;
		
		if ( i2cSlaveBytesReceieved >= 3 )
		{		
			I2C_SLAVE_COMMAND command = (I2C_SLAVE_COMMAND)i2cSlaveWriteBuffer[0];
			uint16_t length = ( i2cSlaveWriteBuffer[1] << 8 ) + i2cSlaveWriteBuffer[2];
			uint8_t *data = &i2cSlaveWriteBuffer[3];
			
			if ( i2cSlaveBytesReceieved >= (3 + length) )
			{
				switch (command)
				{
					case I2C_SLAVE_COMMAND_GET_VERSION:
						i2cSlaveReadBuffer[0] = VERSION_MAJOR;
						i2cSlaveReadBuffer[1] = VERSION_MINOR;
						i2cSlaveReadBuffer[2] = VERSION_SUBMINOR;

						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						break;

					case I2C_SLAVE_COMMAND_GET_INTERRUPT_STATUS:
						i2cSlaveReadBuffer[0] = statusReg;

						// clear flags
						statusReg = 0;

						// clear ISR - this makes it open-drain input (high))
						nLOGIC_INT_SetDigitalInput();
						
						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						break;

					case I2C_SLAVE_COMMAND_GET_POWER:
						i2cSlaveReadBuffer[0] = conversPowerGet();

						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						break;
	
					case I2C_SLAVE_COMMAND_SET_POWER:
						conversPowerSet(*data);
						break;
						
					case I2C_SLAVE_COMMAND_GET_INPUT:
						{
						COMMS_INPUT input;
						CONVERS_INPUT conversInput = conversInputGet();
						
						switch( conversInput )
						{
							case CONVERS_INPUT_PHONO:
								input = COMMS_INPUT_PHONO;
								break;
								
							case CONVERS_INPUT_AUX:
								input = COMMS_INPUT_AUX;
								break;
								
							case CONVERS_INPUT_THEATER:
								input = COMMS_INPUT_THEATER;
								break;
								
							case CONVERS_INPUT_RADIO:
								input = COMMS_INPUT_RADIO;
								break;
								
							case CONVERS_INPUT_SERVER:
								input = COMMS_INPUT_SERVER;
								break;
								
							case CONVERS_INPUT_DAC:
								input = COMMS_INPUT_DAC;
								break;
								
							case CONVERS_INPUT_COAXIAL:
								input = COMMS_INPUT_COAXIAL;
								break;
								
							case CONVERS_INPUT_OPTICAL:
								input = COMMS_INPUT_OPTICAL;
								break;
								
							case CONVERS_INPUT_USB:
								input = COMMS_INPUT_USB;
								break;
								
							case CONVERS_INPUT_NETWORK:
								input = COMMS_INPUT_NETWORK;
								break;
								
							default:
								// unsupported input
								break;
						}
						
						
						i2cSlaveReadBuffer[0] = (uint8_t)input;

						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						}
						break;
						
					case I2C_SLAVE_COMMAND_SET_INPUT:
						{
						COMMS_INPUT input = (COMMS_INPUT)*data;
						
						switch( input )
						{
							case COMMS_INPUT_PHONO:
								conversInputSet(CONVERS_INPUT_PHONO);
								break;
								
							case COMMS_INPUT_AUX:
								conversInputSet(CONVERS_INPUT_AUX);
								break;
								
							case COMMS_INPUT_THEATER:
								conversInputSet(CONVERS_INPUT_THEATER);
								break;
								
							case COMMS_INPUT_RADIO:
								conversInputSet(CONVERS_INPUT_RADIO);
								break;
								
							case COMMS_INPUT_SERVER:
								conversInputSet(CONVERS_INPUT_SERVER);
								break;
								
							case COMMS_INPUT_DAC:
								conversInputSet(CONVERS_INPUT_DAC);
								break;
								
							case COMMS_INPUT_COAXIAL:
								conversInputSet(CONVERS_INPUT_COAXIAL);
								controlSetInput(CONTROL_INPUT_COAX1);
								break;
								
							case COMMS_INPUT_OPTICAL:
								conversInputSet(CONVERS_INPUT_OPTICAL);
								controlSetInput(CONTROL_INPUT_OPTICAL1);
								break;
								
							case COMMS_INPUT_USB:
								conversInputSet(CONVERS_INPUT_USB);
								controlSetInput(CONTROL_INPUT_USB);
								break;
								
							case COMMS_INPUT_NETWORK:
								conversInputSet(CONVERS_INPUT_NETWORK);
								controlSetInput(CONTROL_INPUT_STREAMER);
								break;
								
							default:
								// unknown input
								break;
						}
						}
						break;

					case I2C_SLAVE_COMMAND_GET_VOLUME:
						i2cSlaveReadBuffer[0] = conversVolumeGet();

						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						break;

					case I2C_SLAVE_COMMAND_SET_VOLUME:
						conversVolumeSet(*data);
						break;					
						
					case I2C_SLAVE_COMMAND_GET_MUTE:
						i2cSlaveReadBuffer[0] = conversMuteGet();

						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						break;
						
					case I2C_SLAVE_COMMAND_SET_MUTE:
						conversMuteSet(*data);
						break;
						
					case I2C_SLAVE_COMMAND_GET_BALANCE:
						i2cSlaveReadBuffer[0] = conversBalanceGet();

						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						break;
						
					case I2C_SLAVE_COMMAND_SET_BALANCE:
						conversBalanceSet(*data);
						break;
						
					case I2C_SLAVE_COMMAND_GET_PHASE:
						i2cSlaveReadBuffer[0] = conversPhaseGet();

						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						break;
						
					case I2C_SLAVE_COMMAND_SET_PHASE:
						conversPhaseSet(*data);
						break;
						
					case I2C_SLAVE_COMMAND_GET_DARKMODE:
						i2cSlaveReadBuffer[0] = conversDarkModeGet();

						i2cSlaveReadBufferPtr = i2cSlaveReadBuffer;
						I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
						break;
	
					case I2C_SLAVE_COMMAND_SET_DARKMODE:
						conversDarkModeSet(*data);
						break;
						
					case I2C_SLAVE_COMMAND_CONFIGURE_WIFI:
						converseWifiConfigEnable(*data);
						break;
						
					default:
						// unsupported command
						break;
				}
			}
			
			i2cSlaveCommandPending = false;
		}
	}
}

void commsNotifyHost(uint8_t whatChangedMask)
{
	statusReg |= whatChangedMask;
	nLOGIC_INT_SetLow();
	nLOGIC_INT_SetDigitalOutput();	// pull the interrupt line low
}

bool I2C2_StatusCallback(I2C2_SLAVE_DRIVER_STATUS status)
{
	switch (status)
	{
		case I2C2_SLAVE_TRANSMIT_REQUEST_DETECTED:
			I2C2_ReadPointerSet(i2cSlaveReadBufferPtr);
			i2cSlaveReadBufferPtr++;
			i2cSlaveCommandPending = false;
			
// @todo make sure we don't overwrite ...
			
			break;
			
		case I2C2_SLAVE_RECEIVE_REQUEST_DETECTED:
			i2cSlaveWriteBufferPtr = i2cSlaveWriteBuffer;
			I2C2_WritePointerSet(i2cSlaveWriteBufferPtr);
			i2cSlaveCommandPending = false;
			
// @todo make sure we don't overwrite ...
			break;
			
		case I2C2_SLAVE_RECEIVED_DATA_DETECTED:
			i2cSlaveWriteBufferPtr++;
			I2C2_WritePointerSet(i2cSlaveWriteBufferPtr);			
			i2cSlaveCommandPending = true;
			
// @todo make sure we don't overwrite ...
			break;
			
		default:
			break;
	}
	
	return true;
}