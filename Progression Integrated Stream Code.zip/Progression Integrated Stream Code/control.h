#ifndef _CONTROL_H
#define _CONTROL_H

typedef enum
{
	CONTROL_INPUT_COAX1,
	CONTROL_INPUT_OPTICAL1,
	CONTROL_INPUT_USB,
	CONTROL_INPUT_STREAMER,
		
	CONTROL_NUM_INPUTS	// leave last
} CONTROL_INPUT;

void controlInit(void);
void controlMgr(void);
CONTROL_INPUT controlGetInput(void);
void controlSetInput(CONTROL_INPUT input);

#endif