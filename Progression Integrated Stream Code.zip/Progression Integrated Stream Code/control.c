#include "system.h"

typedef struct
{
	CONTROL_INPUT	input;
	
} Control_Data_t;

static Control_Data_t controlData;

void controlInit(void)
{	
	nFPGA_RESET_SetHigh();
	
	controlSetInput(CONTROL_INPUT_STREAMER);
}

void controlMgr(void)
{
	// nothing to do here
}

CONTROL_INPUT controlGetInput(void)
{
	return controlData.input;
}

void controlSetInput(CONTROL_INPUT input)
{
	if ( input < CONTROL_NUM_INPUTS )
	{
		controlData.input = input;
	}
	
	switch( controlData.input )
	{
		case CONTROL_INPUT_COAX1:
			FPGA_SEL1_SetLow();
			FPGA_SEL0_SetLow();
			
			ess9038SetInput( ESS9038_INPUT_SPDIF );
			break;
						
		case CONTROL_INPUT_OPTICAL1:
			FPGA_SEL1_SetLow();
			FPGA_SEL0_SetHigh();
			
			ess9038SetInput( ESS9038_INPUT_SPDIF );
			break;
			
		case CONTROL_INPUT_USB:
			FPGA_SEL1_SetHigh();
			FPGA_SEL0_SetLow();
			
			ess9038SetInput( ESS9038_INPUT_I2S );
			break;
			
		case CONTROL_INPUT_STREAMER:
			FPGA_SEL1_SetHigh();
			FPGA_SEL0_SetHigh();
			
			ess9038SetInput( ESS9038_INPUT_I2S );
			break;
			
		default:
			FPGA_SEL1_SetLow();
			FPGA_SEL0_SetLow();
			break;		
	}
}