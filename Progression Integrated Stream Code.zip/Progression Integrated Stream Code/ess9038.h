#ifndef _ESS9038_H
#define _ESS9038_H

typedef enum
{
	ESS9038_INPUT_AUTO,
	ESS9038_INPUT_SPDIF,
	ESS9038_INPUT_I2S,
		
	ESS9038_NUM_INPUTS // leave last
} ESS9038_INPUT;

void ess9038Init(void);
void ess9038Mgr(void);
void ess9038SetInput(ESS9038_INPUT input);

#endif