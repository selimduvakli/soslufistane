#ifndef __SYSTEM_H
#define	__SYSTEM_H

#define    FCY    3685000UL    // Instruction cycle frequency, Hz - required for __delayXXX() to work

#define VERSION_MAJOR		0x00
#define VERSION_MINOR		0x01
#define VERSION_SUBMINOR	0x00

#include <libpic30.h>        // __delayXXX() functions macros defined here
#include <string.h>

#include "STREAMER.x/mcc_generated_files/system.h"
#include "STREAMER.x/mcc_generated_files/pin_manager.h"
#include "STREAMER.x/mcc_generated_files/uart1.h"
#include "STREAMER.x/mcc_generated_files/i2c1.h"
#include "STREAMER.x/mcc_generated_files/i2c2.h"

#include "comms.h"
#include "control.h"
#include "convers.h"
#include "ess9038.h"

#endif
