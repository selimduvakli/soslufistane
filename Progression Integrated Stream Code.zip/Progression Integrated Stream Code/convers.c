
#include "system.h"


#define CONVERS_SOP	0x02
#define CONVERS_EOP 0x03

typedef enum
{
	CONVERS_COMMANDCODE_RESET					= 'A',
	CONVERS_COMMANDCODE_WPS						= 'B',
	CONVERS_COMMANDCODE_WIFI_ONOFF				= 'C',
	CONVERS_COMMANDCODE_PLAY_PAUSE				= 'D',
	CONVERS_COMMANDCODE_GET_VOLUME				= 'E',
	CONVERS_COMMANDCODE_SET_VOLUME				= 'F',
	CONVERS_COMMANDCODE_MUTE					= 'G',
	CONVERS_COMMANDCODE_GET_NETWORK_STATUS		= 'H',
	CONVERS_COMMANDCODE_SET_NETWORK_MODE		= 'I',
	CONVERS_COMMANDCODE_GET_GAPLESS_MODE		= 'J',
	CONVERS_COMMANDCODE_SET_GAPLESS_MODE		= 'K',
	CONVERS_COMMANDCODE_SET_SSID				= 'L',
	CONVERS_COMMANDCODE_CONNECT_AP				= 'M',
	CONVERS_COMMANDCODE_SET_LAN_INFO			= 'N',
	CONVERS_COMMANDCODE_SET_WAN_INFO			= 'O',
	CONVERS_COMMANDCODE_FW_UPDATE				= 'P',
	CONVERS_COMMANDCODE_FW_UPDATE_CHECK			= 'Q',
	CONVERS_COMMANDCODE_HOST_FW_INFO			= 'R',
	CONVERS_COMMANDCODE_HOST_FW_IMAGE_SEND		= 'S',
	CONVERS_COMMANDCODE_HOST_FW_IMAGE_END		= 'T',
	CONVERS_COMMANDCODE_SET_PREV_NEXT_PLAY		= 'U',
	CONVERS_COMMANDCODE_HOST_FW_UPDATE_CHECK	= 'V',
	CONVERS_COMMANDCODE_MQA_ONOFF				= 'W',
	CONVERS_COMMANDCODE_VOLUME_ONOFF			= 'X',
	CONVERS_COMMANDCODE_DOP_ONOFF				= 'Y',
	CONVERS_COMMANDCODE_STANDBY_ONOFF			= 'Z',
	CONVERS_COMMANDCODE_ROON_SIGNAL_PATH		= '[',
	CONVERS_COMMANDCODE_DB_VOLUME				= '\\',
	CONVERS_COMMANDCODE_GET_AP_LIST				= ']',
	CONVERS_COMMANDCODE_SET_OUTPUT_TYPE			= '^',
	CONVERS_COMMANDCODE_SOURCE_CHANGE			= '=',

	CONVERS_COMMANDCODE_GET_DEVICE_ID			= 'a',
	CONVERS_COMMANDCODE_GET_HW_VERSION			= 'b',
	CONVERS_COMMANDCODE_GET_FW_VERSION			= 'c',
	CONVERS_COMMANDCODE_GET_DEVICE_NAME			= 'i',
	CONVERS_COMMANDCODE_SET_DEVICE_NAME			= 'j',
		
	CONVERS_COMMANDCODE_EVENT_READY				= '1',
	CONVERS_COMMANDCODE_EVENT_PLAY				= '2',
	CONVERS_COMMANDCODE_EVENT_PAUSE				= '3',
	CONVERS_COMMANDCODE_EVENT_STOP				= '4',
	CONVERS_COMMANDCODE_EVENT_VOLUME			= '5',
	CONVERS_COMMANDCODE_EVENT_LAN_STATUS		= '6',
	CONVERS_COMMANDCODE_EVENT_WIFI_STATUS		= '7',
	CONVERS_COMMANDCODE_EVENT_REBOOTING			= '8',
	CONVERS_COMMANDCODE_EVENT_NOT_SUPPORTED		= '9',
	CONVERS_COMMANDCODE_EVENT_GAPLESS_CHANGED	= ':',
	CONVERS_COMMANDCODE_EVENT_FW_UPDATE			= ';',
	CONVERS_COMMANDCODE_EVENT_FW_UPDATE_PROGRESS= '<',
	CONVERS_COMMANDCODE_EVENT_SOURCE_CHANGE		= '=',
	CONVERS_COMMANDCODE_EVENT_SAMPLERATE		= 'l',
	CONVERS_COMMANDCODE_EVENT_CODECFORMAT		= 'k',
	CONVERS_COMMANDCODE_EVENT_TITLE				= 'p',
	CONVERS_COMMANDCODE_EVENT_ARTIST			= 'q',
	CONVERS_COMMANDCODE_EVENT_ALBUM				= 'r',
	CONVERS_COMMANDCODE_EVENT_MQA_SR			= 0x7F,
		
	CONVERS_COMMANDCODE_APPCONTROL				= 0x77,
    CONVERS_COMMANDCODE_APP_ROON				= 0x6F,
            
		
	CONVERS_COMMANDCODE_ACK						= 0xD0,
	CONVERS_COMMANDCODE_NACK					= 0xD1,
} CONVERS_COMMANDCODE;

typedef enum
{
	CONVERS_APPCONTROL_COMMAND_SETPOWEROFF		= 0x0D,
	CONVERS_APPCONTROL_COMMAND_SETPOWERON		= 0x0E,
    CONVERS_APPCONTROL_COMMAND_SET_roon_POWEROFF    = 0x01,
	CONVERS_APPCONTROL_COMMAND_SET_roon_POWERON		= 0x00,
	CONVERS_APPCONTROL_COMMAND_GETPOWERSTATUS	= 0x0F,
	CONVERS_APPCONTROL_COMMAND_GETBALANCE		= 0x01,
	CONVERS_APPCONTROL_COMMAND_SETBALANCE		= 0x02,
	CONVERS_APPCONTROL_COMMAND_GETINPUT			= 0x17,
	CONVERS_APPCONTROL_COMMAND_SETINPUT			= 0x18,
	CONVERS_APPCONTROL_COMMAND_GETDARKMODE		= 0x1B,
	CONVERS_APPCONTROL_COMMAND_SETDARKMODE		= 0x1C,
	CONVERS_APPCONTROL_COMMAND_GETPHASE			= 0x20,
	CONVERS_APPCONTROL_COMMAND_SETPHASE			= 0x21,
} CONVERS_APPCONTROL_COMMAND;

typedef enum
{
	CONVERS_ERRORCODE_OK						= 0x30,
	CONVERS_ERRORCODE_CHECKSUM_FAILURE			= 0x31,
	CONVERS_ERRORCODE_UNKNOWN_MESSAGE			= 0x32,
	CONVERS_ERRORCODE_LENGTH_ERROR				= 0x33,
	CONVERS_ERRORCODE_UNEXPECTED_ERROR			= 0x34,
} CONVERS_ERRORCODE;

typedef enum
{
	CONVERS_SERIAL_STATE_WAITING_FOR_SOP,
	CONVERS_SERIAL_STATE_WAITING_FOR_HEADER,
	CONVERS_SERIAL_STATE_WAITING_FOR_DATA,
	CONVERS_SERIAL_STATE_WAITING_FOR_EOP,
	CONVERS_SERIAL_STATE_WAITING_FOR_CHECKSUM,
} CONVERS_SERIAL_STATE;

typedef struct
{
	uint8_t sop;
	uint8_t deviceID;
	uint8_t sequenceNumber;
	uint8_t commandCode;
	uint8_t errorCode;
	uint8_t length[2];
} Convers_Header_t;

typedef struct
{
	bool ready;				// true when the ready event is received
	bool power;
	CONVERS_INPUT input;
	uint8_t volume;
	bool mute;
	int8_t balance;
	bool phase;
	bool darkMode;
	bool wifiConfigMode;
} Convers_Data_t;

#define CONVERS_DEFAULT_DEVICE_ID		0x30
#define CONVERS_DEFAULT_SEQUENCE_NUMBER	0x30

static void conversSendInitialConfig(void);
static void conversSendPacket(uint8_t deviceID, CONVERS_COMMANDCODE command, uint16_t length, uint8_t *data);
static void conversProcessMessage(uint8_t *message, uint16_t length);

static Convers_Data_t conversData;

void conversInit(void)
{
	memset( (uint8_t*)&conversData, 0, sizeof(conversData) );
	
	// enable the stream board
	STREAM_EN_SetHigh();
	
	// when it's ready, a "READY" event will be triggered on the serial port
}

void conversMgr(void)
{
	// constantly wait for complete message
	static CONVERS_SERIAL_STATE state = CONVERS_SERIAL_STATE_WAITING_FOR_SOP;
	static uint8_t message[9+64];	// 9 is the message header/footer overhead
	static uint16_t messageBytesReceived;
	static uint16_t messageDataLength;
	
	while( UART1_ReceiveBufferIsEmpty() == false )
	{	
		uint8_t byte = UART1_Read();
		
		switch ( state )
		{
			case CONVERS_SERIAL_STATE_WAITING_FOR_SOP:
				if ( byte == CONVERS_SOP )
				{
					memset( message, 0, sizeof(message) );
					message[0] = byte;
					messageBytesReceived = 1;
					state = CONVERS_SERIAL_STATE_WAITING_FOR_HEADER;
				}
				break;
				
			case CONVERS_SERIAL_STATE_WAITING_FOR_HEADER:
				message[messageBytesReceived++] = byte;
				if ( messageBytesReceived >= 7 )
				{
					Convers_Header_t *header = (Convers_Header_t*)message;
					messageDataLength = ( header->length[1] << 8 ) + header->length[0];
					if (	messageDataLength > 0
						 && messageDataLength < (sizeof(message)-9) )	// -9 accounts for header, eop and checksum
					{
						state = CONVERS_SERIAL_STATE_WAITING_FOR_DATA;
					}
					else
					{
						state = CONVERS_SERIAL_STATE_WAITING_FOR_EOP;
					}
				}
				break;
				
			case CONVERS_SERIAL_STATE_WAITING_FOR_DATA:
				message[messageBytesReceived++] = byte;
				if ( messageBytesReceived >= (7 + messageDataLength) )
				{
					state = CONVERS_SERIAL_STATE_WAITING_FOR_EOP;
				}
				break;
				
			case CONVERS_SERIAL_STATE_WAITING_FOR_EOP:
				if ( byte == CONVERS_EOP )
				{
					message[messageBytesReceived++] = byte;
					state = CONVERS_SERIAL_STATE_WAITING_FOR_CHECKSUM;
				}
				else
				{
					// ERROR - start over!
					state = CONVERS_SERIAL_STATE_WAITING_FOR_SOP;
				}
				break;
				
			case CONVERS_SERIAL_STATE_WAITING_FOR_CHECKSUM:
				{
				message[messageBytesReceived++] = byte;
				
				// calculate the checksum
				uint8_t i;
				uint8_t checksum = 0;
				for( i = 0; i <= (messageBytesReceived-2); i++ )
				{
					checksum ^= message[i];
				}				
				// verify the checksum
				if ( checksum == message[messageBytesReceived-1] )
				{
					// process message
					conversProcessMessage( message, messageBytesReceived );
				}
				
				// start looking for next message
				state = CONVERS_SERIAL_STATE_WAITING_FOR_SOP;
				}
				break;
		}
	}	
}

bool conversPowerGet(void)
{
	return conversData.power;
}

void conversPowerSet(bool enabled)
{
    
	uint8_t data[2];
    
	// AP Volume 00 send power
	conversData.power = enabled;
    
     
    __delay_ms(5);
    // DAGOSTINO AP send power
	data[0] = ( conversData.power ) ? CONVERS_APPCONTROL_COMMAND_SETPOWERON : CONVERS_APPCONTROL_COMMAND_SETPOWEROFF;
	conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
						CONVERS_COMMANDCODE_APPCONTROL,
						1,
						data							);
    
    
    if ( 0  == conversData.power ){
        __delay_ms(5);
		// send volume
		data[0] = conversData.power;
		conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
							CONVERS_COMMANDCODE_SET_VOLUME,
							1,
							data							); 
    }
    
    
   __delay_ms(10);
   
	// ROON AP send power
	data[0] = ( conversData.power ) ? CONVERS_APPCONTROL_COMMAND_SET_roon_POWERON : CONVERS_APPCONTROL_COMMAND_SET_roon_POWEROFF;
	conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
						CONVERS_COMMANDCODE_APP_ROON,
						1,
						data							);
    
    
    if( 1 == conversData.power) {
        __delay_ms(5);
        static uint8_t invert_phase[]={0x7b,0x22,0x73,0x69,0x67,0x6e,0x61,0x6c,0x5f,0x70,0x61,0x74,0x68,0x22,0x3a,0x5b,0x7b,0x22,0x71,0x75,0x61,0x6c,0x69,0x74,0x79,0x22,0x3a,0x22,0x6c,0x6f,0x73,0x73,0x6c,0x65,0x73,0x73,0x22,0x2c,0x22,0x74,0x79,0x70,0x65,0x22,0x3a,0x22,0x6f,0x75,0x74,0x70,0x75,0x74,0x22,0x2c,0x22,0x6d,0x65,0x74,0x68,0x6f,0x64,0x22,0x3a,0x22,0x73,0x70,0x65,0x61,0x6b,0x65,0x72,0x73,0x22,0x7d,0x5d,0x7d,0x03,0x53}; 
          jSonSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
			CONVERS_COMMANDCODE_ROON_SIGNAL_PATH,
			76,
			invert_phase						);
          __delay_ms(5);
    }
    
}

CONVERS_INPUT conversInputGet(void)
{
	return conversData.input;
}

void conversInputSet(CONVERS_INPUT input)
{
	if ( input < CONVERS_NUM_INPUTS )
	{	
		uint8_t data[2];

		conversData.input = input;
	
		data[0] = CONVERS_APPCONTROL_COMMAND_SETINPUT;
		data[1] = (uint8_t)conversData.input;
		conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
							CONVERS_COMMANDCODE_APPCONTROL,
							2,
							data							);
        
        
    
      if ( input != CONVERS_INPUT_NETWORK )
             {
        uint8_t data1 = 0xFF;
        __delay_ms(5);
                    
        data[0] = 0x00;             // setting the volume level because of source changing
		conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
							CONVERS_COMMANDCODE_SET_VOLUME,
							1,
							data							);
        
         __delay_ms(10);
           conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
							CONVERS_COMMANDCODE_SOURCE_CHANGE,
							1,
							&data1							); 
              }
	}
}

uint8_t conversVolumeGet(void)
{
	return conversData.volume;
}

void conversVolumeSet(uint8_t volume)
{
	if ( volume <= 100 )
	{	
		uint8_t data[2];

		conversData.volume = volume;

		// send volume
		data[0] = conversData.volume;
		conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
							CONVERS_COMMANDCODE_SET_VOLUME,
							1,
							data							);
	}
}

bool conversMuteGet(void)
{
	return conversData.mute;
}

void conversMuteSet(bool enabled)
{
	conversData.mute = enabled;
		
	// send mute
	uint8_t data = ( conversData.mute ) ? 1 : 0;
	conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
						CONVERS_COMMANDCODE_MUTE,
						1,
						&data							);
}

int8_t conversBalanceGet(void)
{
	return conversData.balance;
}

void conversBalanceSet(int8_t balance)
{
	uint8_t data[2];

	conversData.balance = balance;
    
    // Roon AP send
                //  size_t data1= '{ "signal_path": [ { "quality": "lossless", "type": "balance",  "value": -1.0<->1.0 } ] }';
    if(conversData.balance != 0) {
 //76 spker static uint8_t invert_phase[]={0x7b,0x22,0x73,0x69,0x67,0x6e,0x61,0x6c,0x5f,0x70,0x61,0x74,0x68,0x22,0x3a,0x5b,0x7b,0x22,0x71,0x75,0x61,0x6c,0x69,0x74,0x79,0x22,0x3a,0x22,0x6c,0x6f,0x73,0x73,0x6c,0x65,0x73,0x73,0x22,0x2c,0x22,0x74,0x79,0x70,0x65,0x22,0x3a,0x22,0x6f,0x75,0x74,0x70,0x75,0x74,0x22,0x2c,0x22,0x6d,0x65,0x74,0x68,0x6f,0x64,0x22,0x3a,0x22,0x73,0x70,0x65,0x61,0x6b,0x65,0x72,0x73,0x22,0x7d,0x5d,0x7d,0x03,0x53};
            static uint8_t roon_balance[]={0x7b,0x22,0x73,0x69,0x67,0x6e,0x61,0x6c,0x5f,0x70,0x61,0x74,0x68,0x22,0x3a,0x5b,0x7b,0x22,0x71,0x75,0x61,0x6c,0x69,0x74,0x79,0x22,0x3a,0x22,0x6c,0x6f,0x73,0x73,0x6c,0x65,0x73,0x73,0x22,0x2c,0x22,0x74,0x79,0x70,0x65,0x22,0x3a,0x22,0x62,0x61,0x6c,0x61,0x6e,0x63,0x65,0x22,0x2c,0x22,0x76,0x61,0x6c,0x75,0x65,0x22,0x3a,0x2d,0x31,0x2e,0x30,0x3c,0x2d,0x3e,0x31,0x2e,0x30,0x7d,0x5d,0x7d,0x03,0x53};
            jSonSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
			CONVERS_COMMANDCODE_ROON_SIGNAL_PATH,
			76,
			roon_balance							);
            
    // Dan Dagostino app sent
	data[0] = CONVERS_APPCONTROL_COMMAND_SETBALANCE;
	data[1] = conversData.balance;
    __delay_ms(10);
	conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
						CONVERS_COMMANDCODE_APPCONTROL,
						2,
						data							);
            
    
    }

}

bool conversPhaseGet(void)
{
	return conversData.phase;
}

void conversPhaseSet(bool outOfPhase)
{
    uint8_t data[2];
	conversData.phase = outOfPhase;
    // Roon AP send phase
    if(conversData.phase == 1) {

     static uint8_t invert_phase[]={0x7b,0x22,0x73,0x69,0x67,0x6e,0x61,0x6c,0x5f,0x70,0x61,0x74,0x68,0x22,0x3a,0x5b,0x7b,0x22,0x71,0x75,0x61,0x6c,0x69,0x74,0x79,0x22,0x3a,0x22,0x6c,0x6f,0x73,0x73,0x6c,0x65,0x73,0x73,0x22,0x2c,0x22,0x74,0x79,0x70,0x65,0x22,0x3a,0x22,0x69,0x6e,0x76,0x65,0x72,0x74,0x5f,0x70,0x68,0x61,0x73,0x65,0x22,0x7d,0x5d,0x7d};
               // static uint8_t invert_phase[]={0x7b,0x22,0x73,0x69,0x67,0x6e,0x61,0x6c,0x5f,0x70,0x61,0x74,0x68,0x22,0x3a,0x5b,0x7b,0x22,0x74,0x79,0x70,0x65,0x22,0x3a,0x22,0x69,0x6e,0x76,0x65,0x72,0x74,0x5f,0x70,0x68,0x61,0x73,0x65,0x22,0x2c,0x22,0x71,0x75,0x61,0x6c,0x69,0x74,0x79,0x22,0x3a,0x22,0x6c,0x6f,0x73,0x73,0x6c,0x65,0x73,0x73,0x22,0x2c,0x22,0x74,0x79,0x70,0x65,0x22,0x3a,0x22,0x61,0x6d,0x70,0x6c,0x69,0x66,0x69,0x65,0x72,0x22,0x2c,0x22,0x6d,0x65,0x74,0x68,0x6f,0x64,0x22,0x3a,0x22,0x61,0x6e,0x61,0x6c,0x6f,0x67,0x22,0x7d,0x5d,0x7d,0x03,0x53};
            //static uint8_t invert_phase[]={0x69,0x6e,0x76,0x65,0x72,0x74,0x5f,0x70,0x68,0x61,0x73,0x65};
          jSonSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
			CONVERS_COMMANDCODE_ROON_SIGNAL_PATH,
			61,
			invert_phase						);
            

        __delay_ms(20);
    }
    //Dan Dagostino APP
	// send phase
	data[0] = CONVERS_APPCONTROL_COMMAND_SETPHASE;
	data[1] = (conversData.phase) ? 1 : 0;
	conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
            
						CONVERS_COMMANDCODE_APPCONTROL,
						2,
						data							);
    
}

bool conversDarkModeGet(void)
{
	return conversData.darkMode;
}

void conversDarkModeSet(bool enabled)
{
	uint8_t data[2];

	conversData.darkMode = enabled;
	
	// send dark mode
	data[0] = CONVERS_APPCONTROL_COMMAND_SETDARKMODE;
	data[1] = (conversData.darkMode) ? 1 : 0;
	conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
						CONVERS_COMMANDCODE_APPCONTROL,
						2,
						data							);
}

void converseWifiConfigEnable(bool enable)
{
	// this command is a toggle, so we can't specifically enable/disable
	
	uint8_t data = 0x02;

	conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
						CONVERS_COMMANDCODE_SET_NETWORK_MODE,
						1,
						&data									);
}

static void conversProcessMessage(uint8_t *message, uint16_t length)
{
	Convers_Header_t *header = (Convers_Header_t*)message;
	uint16_t messageLength = ( header->length[1] << 8 ) + header->length[0];
	uint8_t *messageData = &message[sizeof(Convers_Header_t)];
	
	if ( header->errorCode == CONVERS_ERRORCODE_OK )
	{
		switch( header->commandCode )
		{
			case CONVERS_COMMANDCODE_EVENT_READY:
				conversData.ready = true;
				conversSendInitialConfig();
				break;
				
			case CONVERS_COMMANDCODE_EVENT_VOLUME:
				if ( messageLength == 1 )
				{
					// volume is 0-100
					conversData.volume = *messageData;				
					commsNotifyHost(COMMS_WHATCHANGED_VOLUME);
				}
				break;
			
			case CONVERS_COMMANDCODE_MUTE:
				if ( messageLength == 1 )
				{
					conversData.mute = *messageData;
                    uint8_t data = ( conversData.mute ) ? 1 : 0;
                        conversSendPacket(	CONVERS_DEFAULT_DEVICE_ID,
						CONVERS_COMMANDCODE_MUTE,
						1,
						&data							);
                        __delay_ms(5);
					commsNotifyHost(COMMS_WHATCHANGED_MUTE);
				}
				break;
            
            case CONVERS_COMMANDCODE_EVENT_PLAY:    //Play to input Network 
                
                if ( conversData.power == 1 && conversData.input != 0x0A)
				{
                 conversData.input = 0x0A;
                 conversInputSet(CONVERS_INPUT_NETWORK);
                 __delay_ms(5);
                 commsNotifyHost(COMMS_WHATCHANGED_INPUT);
				}
                 break;
		case CONVERS_COMMANDCODE_APP_ROON:          // Roon ON OFF
                 if ( messageData[1]== 0x03)                          // when title message came it is confusing. So for get rid of this control
                 {
 				switch ( messageData[0] )
				{
					case CONVERS_APPCONTROL_COMMAND_SET_roon_POWEROFF:
						conversData.power = false;                  // Power 0
                        conversData.volume = 0x00;                  // Volume 0			
                        commsNotifyHost(COMMS_WHATCHANGED_VOLUME); 
                        __delay_ms(5);
						commsNotifyHost(COMMS_WHATCHANGED_POWER);  
						break;
						
					case CONVERS_APPCONTROL_COMMAND_SET_roon_POWERON:
						conversData.power = true;                      // Power 1
                        conversData.input = 0x0A;                      // input network
                        commsNotifyHost(COMMS_WHATCHANGED_POWER);
                        __delay_ms(5);
                        commsNotifyHost(COMMS_WHATCHANGED_INPUT);
						break;
                }
                }
                 break;
                 
                 
			case CONVERS_COMMANDCODE_APPCONTROL:
				switch ( messageData[0] )
				{
					case CONVERS_APPCONTROL_COMMAND_SETPOWEROFF:
						conversData.power = false;
						commsNotifyHost(COMMS_WHATCHANGED_POWER);
						break;
						
					case CONVERS_APPCONTROL_COMMAND_SETPOWERON:
						conversData.power = true;
						commsNotifyHost(COMMS_WHATCHANGED_POWER);
						break;
						
					case CONVERS_APPCONTROL_COMMAND_SETBALANCE:
						conversData.balance = messageData[1];
						commsNotifyHost(COMMS_WHATCHANGED_BALANCE);
						break;
												
					case CONVERS_APPCONTROL_COMMAND_SETINPUT:
                        
						if ( messageData[1] < CONVERS_NUM_INPUTS && messageData[2] == 0x03 )
						{
                            if ( messageData[1] >= 0x01)
                            {
							conversData.input = messageData[1];
							commsNotifyHost(COMMS_WHATCHANGED_INPUT);
						
							switch( conversData.input )
							{								
								case CONVERS_INPUT_COAXIAL:
									controlSetInput( CONTROL_INPUT_COAX1 );
									break;

								case CONVERS_INPUT_OPTICAL:
									controlSetInput( CONTROL_INPUT_OPTICAL1 );
									break;

								case CONVERS_INPUT_USB:
									controlSetInput( CONTROL_INPUT_USB );
									break;

								case CONVERS_INPUT_NETWORK:
									controlSetInput( CONTROL_INPUT_STREAMER );
									break;

								default:
									// unsupported input
									break;
							}
                            }
						}
						break;
												
					case CONVERS_APPCONTROL_COMMAND_SETDARKMODE:
						conversData.darkMode = messageData[1];
						commsNotifyHost(COMMS_WHATCHANGED_DARKMODE);
						break;
						
					case CONVERS_APPCONTROL_COMMAND_SETPHASE:
						conversData.phase = messageData[1];
						commsNotifyHost(COMMS_WHATCHANGED_PHASE);
						break;
						
					default:
						// unsupported command
						break;
				}
				break;
				
			case CONVERS_COMMANDCODE_ACK:
				break;
				
			case CONVERS_COMMANDCODE_EVENT_LAN_STATUS:
				break;
				
			case CONVERS_COMMANDCODE_EVENT_WIFI_STATUS:
				break;
				
			default:
				// unsupported command
				break;
		}
	}
}

static void conversSendInitialConfig(void)
{
	conversPowerSet(conversData.power);
	conversInputSet(conversData.input);
    conversMuteSet(conversData.mute);
	conversVolumeSet(conversData.volume);
	conversBalanceSet(conversData.balance);
	conversPhaseSet(conversData.phase);
	conversDarkModeSet(conversData.darkMode);
}

static void conversSendPacket(uint8_t deviceID, CONVERS_COMMANDCODE command, uint16_t length, uint8_t *data)
{
	if (	conversData.ready
		 &&	length <= 32		)
	{	
		uint8_t buffer[32 + 9]; // 9 is the overhead bytes

		uint8_t *pBuffer = buffer;

		*pBuffer++ = CONVERS_SOP;
		*pBuffer++ = deviceID;
		*pBuffer++ = CONVERS_DEFAULT_SEQUENCE_NUMBER;
		*pBuffer++ = command;
		*pBuffer++ = CONVERS_ERRORCODE_OK;
		*pBuffer++ = length;
		*pBuffer++ = length >> 8;
		if ( length > 0 )
		{
			memcpy( pBuffer, data, length );
			pBuffer += length;
		};
		*pBuffer++ = CONVERS_EOP;
		
		// calculate the checksum
		uint8_t i;
		uint8_t checksum = 0;
		for( i = 0; i < (8 + length); i++ )	// 8 is the overhead - the LRC
		{
			checksum ^= buffer[i];
		}
		*pBuffer++ = checksum;
		
		UART1_WriteBuffer( buffer, (9 + length) );
	}
}

void jSonSendPacket(uint8_t deviceID, CONVERS_COMMANDCODE command, uint16_t length, uint8_t *data)
{
	if (	conversData.ready
		 &&	length <= 128		)
	{	
		uint8_t buffer[128]; // 9 is the overhead bytes

		uint8_t *pBuffer = buffer;

		*pBuffer++ = CONVERS_SOP;
		*pBuffer++ = deviceID;
		*pBuffer++ = CONVERS_DEFAULT_SEQUENCE_NUMBER;
		*pBuffer++ = command;
		*pBuffer++ = CONVERS_ERRORCODE_OK;
		*pBuffer++ = length;
		*pBuffer++ = length >> 8;
		if ( length > 0 )
		{
			memcpy( pBuffer, data, length );
			pBuffer += length;
		};
        
		*pBuffer++ = CONVERS_EOP;
		
		// calculate the checksum
		uint8_t i;
		uint8_t checksum = 0;
		for( i = 0; i < (8 + length); i++ )	// 8 is the overhead - the LRC
		{
			checksum ^= buffer[i];
		}
		*pBuffer++ = checksum;
		
		UART1_WriteBuffer( buffer, (9 + length) );
	}
}

   
         
